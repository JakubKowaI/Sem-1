double f(double x);
double rozwiazanie(double a,double b,double eps);