#include <stdio.h>
#include <math.h>
#include "funs.h"

double f(double x){
    return cos(x/2.0);
}