#include <stdio.h>
#include <math.h>
#include "funs.h"

int main (){
    printf("%lf",rozwiazanie(2,6,pow(10,-8)));
    return 0;
}