#include <stdbool.h>

bool p(char napis[]);