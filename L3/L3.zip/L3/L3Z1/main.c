#include <stdio.h>
#include "funs.h"

int main(){
    printf("%d",p("racecar"));
    return 0;
}