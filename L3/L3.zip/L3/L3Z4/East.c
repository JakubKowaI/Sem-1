#include "agents.h"

void East(struct agent *a){
    a->x+=1;
}