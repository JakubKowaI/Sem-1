#include "agents.h"

void West(struct agent *a){
    a->x-=1;
}