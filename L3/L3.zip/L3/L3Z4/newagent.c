#include "agents.h"

struct agent newagent(int a,int b)
{
    struct agent newagent1={a,b};
    return newagent1;
};