#include "agents.h"

void North(struct agent *a){
    a->y+=1;    
}