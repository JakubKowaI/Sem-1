#include "agents.h"

void South(struct agent *a){
    a->y-=1;
}