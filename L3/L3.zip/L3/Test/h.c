// h.c
#include <stdio.h>
#include "funs.h"
void h(char s[])
{
printf("h: dostałam napis %s\n", s);
}