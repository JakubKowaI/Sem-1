// g.c
#include <stdio.h>
#include "funs.h"
void g(int n)
{
printf("g: dostałam liczbę %d\n", n);
}