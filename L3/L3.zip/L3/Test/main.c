// main.c
#include "funs.h"
int main(void)
{
f();
return 0;
}