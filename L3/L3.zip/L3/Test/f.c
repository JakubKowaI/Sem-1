// f.c
#include "funs.h"
void f(void)
{
g(13);
h("to jest tekst");
}