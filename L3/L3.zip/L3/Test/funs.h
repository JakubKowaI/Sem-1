// funs.h

void f(void);
void g(int n);
void h(char s[]);