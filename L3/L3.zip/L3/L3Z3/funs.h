int phi(long int n);
int NWD(int a,int b);