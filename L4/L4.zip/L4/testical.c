#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int generateRandomNumber() {
    srand(time(NULL));
    int randomNumber = rand() % 352 + 69;
    return randomNumber;
}

int main() {
    int randomNum = generateRandomNumber();
    printf("Random number: %d\n", randomNum);
    return 0;
}
